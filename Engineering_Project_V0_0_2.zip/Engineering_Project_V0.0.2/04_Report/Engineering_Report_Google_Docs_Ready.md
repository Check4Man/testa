# Engineering Design Report — V0.0.0
**Part:** BRK-200-400-V0  
**Status:** Preliminary concept; not approved for load-bearing use

## 1. Objective
Develop a two-bracket assembly within a nominal 200 × 400 mm envelope, using a commercially sourced beam and 3D-printed press-fit brackets, with a minimum 10 N static load requirement.

## 2. Design interpretation
The source request did not define the exact mounting orientation, hole coordinates, load direction, or interface geometry. This release assumes a 400 mm simply supported 20 × 20 × 2 mm 6061-T6 aluminium square tube and two identical printed end brackets. Each bracket has two M5 clearance holes and a nominal square socket.

## 3. CAD and manufacturing
The parametric OpenSCAD source is `01_CAD/OpenSCAD/bracket_pair.scad`. Units are mm. The socket clearance is a tunable starting parameter only. OpenSCAD does not natively export STEP; a STEP-capable CAD bridge is required. STL can be exported from OpenSCAD and/or generated from a Gmsh mesh.

## 4. Material selection
Proposed beam: 6061-T6 aluminium square tube, 20 × 20 × 2 mm. The exact supplier and product code remain open. Script inputs E=69 GPa and yield=240 MPa are provisional placeholders and must be replaced with source-confirmed values.
Proposed bracket: PETG. Script inputs E=1.8 GPa and tensile strength=30 MPa are placeholders only. Printed strength depends on filament, orientation, process, temperature, and conditioning.

## 5. Calculation method
The Python model calculates square hollow-section second moment of area, maximum bending moment/stress, midspan deflection, and a simplified bracket-root bending screen. Automated decision logic fails excessive stresses/deflection and holds if material/geometry evidence is unverified.

## 6. FEA plan
Use Gmsh for 3D tetrahedral meshing and CalculiX for the structural solve. Include realistic mounting constraints, socket/beam load transfer, material anisotropy where data permit, mesh convergence, reaction balance, and local stress review. No solved FEA result is claimed in this release.

## 7. Verification status
- Parametric concept CAD: provided.
- Analytical Python checks: provided.
- Automated test suite: provided.
- Gmsh workflow: provided.
- Solved FEA: not yet completed.
- Supplier evidence: not yet complete.
- Physical proof test: not yet completed.
- STEP: not yet generated.

## 8. Decision
**HOLD — DATA NOT VERIFIED.** The next decision requires a mounting sketch, confirmed beam supplier/datasheet, selected filament datasheet and print coupon properties, completed 3D FEA, and physical 10 N proof test.
