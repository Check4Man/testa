# Requirements and verification matrix
| ID | Requirement | V0.0.0 interpretation | Verification | Status |
|---|---|---|---|---|
| R-01 | 200 × 400 cm? | Interpreted as 200 × 400 mm | CAD envelope check | ASSUMED |
| R-02 | 3D printed brackets | Two identical PETG concept brackets | OpenSCAD model + print inspection | MODEL REVISED V0.0.2 — NOT RENDERED IN OPENSCAD |
| R-03 | Press fit beam | 20.4 mm nominal socket for nominal 20 mm tube | Coupon fit test; measure actual tube | NOT VERIFIED |
| R-04 | Two-hole mounting | Two M5 clearance holes per bracket | CAD dimension check | MODEL PROVIDED |
| R-05 | Withstand at least 10 N | 10 N downward at beam midspan | Python screening + 3D FEA + physical test | SCREENING ONLY |
| R-06 | Commercial beam with known section/properties | 6061-T6 aluminium 20×20×2 mm tube assumption | Supplier datasheet and incoming inspection | SOURCE TO CONFIRM |
| R-07 | STEP file | STEP export via STEP-capable CAD bridge | Open STEP and inspect dimensions | NOT GENERATED |
| R-08 | FEA shown in 3D | Gmsh mesh + CalculiX solver workflow | Converged solve and postprocessing | TEMPLATE ONLY |
| R-09 | Python calculation and automated test | Scripted checks and PASS/FAIL report | Run test suite | PROVIDED |
| R-10 | Google Docs report | DOCX/Markdown import-ready report | Import into Google Docs | PROVIDED FOR IMPORT |

## Automated test coverage (audit entry 002, 2026-11-19)
38 tests, all passing. Details and open actions: `06_Validation/TEST_AUDIT_LOG.md`.
| ID | Automated test today | Remaining gap |
|---|---|---|
| R-01 | default span only | A-07: envelope check, mm or cm |
| R-02 | 10 geometry tests on the Python mirror | A-13: real OpenSCAD render |
| R-03 | cavity width sanity only | A-02: press fit or slip fit |
| R-04 | holes: count, pitch, open, edge distance | physical fit test |
| R-05 | default load, 10x margin, golden values | FEA, physical proof test |
| R-06 | none (placeholder values) | evidence in `05_Evidence/` |
| R-07 | none | export STEP |
| R-08 | none | A-12, run FEA |
| R-09 | 25 calculation tests; 20 of 20 detectable mutations caught | A-11 |
| R-10 | none | report is stale (V0.0.0); regenerate |
