"""Transparent preliminary engineering checks. Units: N, mm, MPa."""
from dataclasses import dataclass, asdict
import json, math

@dataclass
class Inputs:
    load_N: float = 10.0
    span_mm: float = 400.0
    beam_outer_mm: float = 20.0
    beam_wall_mm: float = 2.0
    beam_E_MPa: float = 69000.0
    beam_yield_MPa: float = 240.0
    bracket_E_MPa: float = 1800.0       # provisional PETG placeholder
    bracket_tensile_MPa: float = 30.0   # provisional PETG placeholder
    bracket_width_mm: float = 80.0
    bracket_root_thickness_mm: float = 8.0
    bracket_load_eccentricity_mm: float = 30.0
    safety_factor: float = 2.0
    material_data_verified: bool = False
    geometry_verified: bool = False

_MUST_BE_POSITIVE = (
    "span_mm", "beam_outer_mm", "beam_wall_mm", "beam_E_MPa", "beam_yield_MPa",
    "bracket_E_MPa", "bracket_tensile_MPa", "bracket_width_mm",
    "bracket_root_thickness_mm", "safety_factor",
)

def validate(x):
    """Reject physically meaningless inputs with ValueError (never ZeroDivisionError)."""
    for name in _MUST_BE_POSITIVE:
        if getattr(x, name) <= 0:
            raise ValueError(f"{name} must be > 0 (got {getattr(x, name)}).")
    if x.load_N < 0:
        raise ValueError(f"load_N must be >= 0 (got {x.load_N}).")
    if x.bracket_load_eccentricity_mm < 0:
        raise ValueError(f"bracket_load_eccentricity_mm must be >= 0 (got {x.bracket_load_eccentricity_mm}).")

def calculate(x=Inputs()):
    validate(x)
    P,L,B,t = x.load_N,x.span_mm,x.beam_outer_mm,x.beam_wall_mm
    b = B - 2*t
    if b <= 0: raise ValueError("Beam wall thickness leaves no hollow section.")
    I = (B**4-b**4)/12.0
    M = P*L/4.0
    sigma_beam = M*(B/2)/I
    delta = P*L**3/(48*x.beam_E_MPa*I)
    beam_allow = x.beam_yield_MPa/x.safety_factor

    # Simplified per-bracket cantilever root stress screen
    R = P/2.0
    Mb = R*x.bracket_load_eccentricity_mm
    Ib = x.bracket_width_mm*x.bracket_root_thickness_mm**3/12.0
    sigma_bracket = Mb*(x.bracket_root_thickness_mm/2)/Ib
    bracket_allow = x.bracket_tensile_MPa/x.safety_factor

    checks = {
        "beam_bending": {"value_MPa": sigma_beam, "allowable_MPa": beam_allow,
                         "pass": sigma_beam <= beam_allow},
        "beam_deflection": {"value_mm": delta, "allowable_mm": L/200,
                            "pass": delta <= L/200},
        "bracket_root_screen": {"value_MPa": sigma_bracket, "allowable_MPa": bracket_allow,
                                "pass": sigma_bracket <= bracket_allow},
    }
    numeric_pass = all(v["pass"] for v in checks.values())
    verified = x.material_data_verified and x.geometry_verified
    if not numeric_pass:
        decision = "FAIL"
        next_action = "REDESIGN: inspect the failed check(s), increase section/fillet/gusset or change material, then rerun."
    elif not verified:
        decision = "HOLD — DATA NOT VERIFIED"
        next_action = "CONTROLLED HOLD: obtain supplier datasheets, confirm dimensions and mounting geometry, then set verification flags and rerun."
    else:
        decision = "ANALYTICAL SCREEN PASS — FEA AND PHYSICAL TEST REQUIRED"
        next_action = "Proceed to converged 3D FEA and a controlled 10 N proof test; do not release before both pass."
    return {
        "inputs": asdict(x),
        "beam": {"I_mm4": I, "Mmax_Nmm": M, "stress_MPa": sigma_beam,
                 "deflection_mm": delta},
        "bracket_screen": {"reaction_N_each": R, "moment_Nmm": Mb,
                           "stress_MPa": sigma_bracket},
        "checks": checks, "decision": decision, "next_action": next_action
    }

if __name__ == "__main__":
    result = calculate()
    print(json.dumps(result, indent=2))
