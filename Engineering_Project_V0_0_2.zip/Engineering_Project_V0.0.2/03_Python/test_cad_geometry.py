"""Geometry tests (R-02, R-03 sanity, R-04) on the voxel mirror of the SCAD file.

These run without OpenSCAD. They test a re-implementation of the SCAD logic
(scad_mirror.py), so they catch parameter and construction mistakes, not
OpenSCAD syntax errors. Resolution is one voxel (PITCH = 0.4 mm).
"""
import unittest

import numpy as np

import scad_mirror as m
from engineering_checks import Inputs


def _idx(axis, value):
    return int(np.argmin(abs(axis - value)))


class BracketGeometry(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p = m.load_params()
        (cls.xs, cls.ys, cls.zs), cls.occ = m.build(cls.p)
        p = cls.p
        cls.y_mid = p["base_d"] - p["wall_t"] - p["socket_depth"] / 2      # middle of the socket block
        cls.z_mid = p["socket_z0"] + p["socket_w"] / 2                     # middle of the cavity
        cls.iy, cls.iz = _idx(cls.ys, cls.y_mid), _idx(cls.zs, cls.z_mid)
        cls.ix = _idx(cls.xs, p["base_w"] / 2)

    # ---- R-02 / audit action A-01: closed, walled socket -------------------------------
    def test_socket_side_walls_present_and_thick_enough(self):
        row = self.occ[:, self.iy, self.iz]
        walls = m.run_lengths(row, m.PITCH)
        self.assertEqual(len(walls), 2, f"expected a wall on each side of the cavity, got {walls}")
        for w in walls:
            self.assertGreaterEqual(w, self.p["socket_wall"] - m.PITCH)

    def test_socket_cavity_width_matches_parameter(self):
        row = self.occ[:, self.iy, self.iz]
        left = right = self.ix                       # grow the empty run outwards from the centre
        while not row[left - 1]:
            left -= 1
        while not row[right + 1]:
            right += 1
        width = (right - left + 1) * m.PITCH
        self.assertAlmostEqual(width, self.p["socket_w"], delta=m.PITCH)
        self.assertAlmostEqual(width, self.p["beam_outer"], delta=1.0)   # sanity: cavity is for a 20 mm tube

    def test_socket_top_and_bottom_walls(self):
        col = self.occ[self.ix, self.iy, :]
        z0, z1 = self.p["socket_z0"], self.p["socket_z0"] + self.p["socket_w"]
        below = col[: _idx(self.zs, z0 - m.PITCH / 2) + 1][::-1]
        above = col[_idx(self.zs, z1 + m.PITCH / 2):]
        floor = np.argmin(below) if not below.all() else len(below)
        top = np.argmin(above) if not above.all() else len(above)
        self.assertGreaterEqual(floor * m.PITCH, self.p["socket_wall"] - m.PITCH, "floor wall too thin")
        self.assertGreaterEqual(top * m.PITCH, self.p["socket_wall"] - m.PITCH, "top wall too thin (socket open at top?)")

    def test_cavity_is_clear_through_full_depth(self):
        p = self.p
        y_front = p["base_d"] - p["wall_t"] - p["socket_depth"]
        sel = (self.ys >= y_front + m.PITCH) & (self.ys <= p["base_d"] - m.PITCH)
        self.assertFalse(self.occ[self.ix, sel, self.iz].any(), "beam cavity is blocked somewhere along its length")

    def test_no_material_outside_foot_footprint(self):
        X, Y, _ = np.meshgrid(self.xs, self.ys, self.zs, indexing="ij")
        p = self.p
        outside = (X < 0) | (X > p["base_w"]) | (Y < 0) | (Y > p["base_d"])
        self.assertEqual(int((self.occ & outside).sum()), 0)

    def test_bracket_height_stays_within_upright_top(self):
        p = self.p
        top = self.zs[np.where(self.occ.any(axis=(0, 1)))[0].max()]
        self.assertLessEqual(top, p["base_t"] + p["upright_h"] + m.PITCH)

    # ---- R-04 / audit action A-09: two mounting holes ----------------------------------
    def test_two_holes_at_specified_pitch(self):
        p = self.p
        self.assertEqual(p["hole_spacing"], 50)
        self.assertGreaterEqual(p["hole_d"], 5.0)   # M5 clearance
        iy = _idx(self.ys, p["base_d"] / 2)
        for hx in (p["base_w"] / 2 - 25, p["base_w"] / 2 + 25):
            col = self.occ[_idx(self.xs, hx), iy, _idx(self.zs, 0.2): _idx(self.zs, p["base_t"] - 0.2) + 1]
            self.assertFalse(col.any(), f"hole at x={hx} is not open through the foot")
        self.assertTrue(self.occ[self.ix, iy, _idx(self.zs, p["base_t"] / 2)], "foot should be solid between the holes")

    def test_holes_are_not_blocked_above_the_foot(self):
        p = self.p
        X, Y, Z = np.meshgrid(self.xs, self.ys, self.zs, indexing="ij")
        for hx in (p["base_w"] / 2 - 25, p["base_w"] / 2 + 25):
            column = ((X - hx) ** 2 + (Y - p["base_d"] / 2) ** 2 <= (p["hole_d"] / 2) ** 2) & (Z >= 0) & (Z <= p["base_t"] + 3)
            self.assertEqual(int((self.occ & column).sum()), 0, f"material in the hole column at x={hx}")

    def test_hole_edge_distance_at_least_two_diameters(self):
        p = self.p
        edge = p["base_w"] / 2 - p["hole_spacing"] / 2 - p["hole_d"] / 2
        self.assertGreaterEqual(edge, 2 * p["hole_d"])

    # ---- consistency with the Python model (partial A-08) -----------------------------
    def test_python_model_uses_the_cad_foot_dimensions(self):
        self.assertEqual(Inputs().bracket_width_mm, self.p["base_w"])
        self.assertEqual(Inputs().bracket_root_thickness_mm, self.p["base_t"])


class TestsDetectTheOldDefect(unittest.TestCase):
    """The V0.0.0/V0.0.1 geometry must violate the checks above (shows they are not vacuous)."""
    @classmethod
    def setUpClass(cls):
        cls.p = m.load_params()
        (cls.xs, cls.ys, cls.zs), cls.occ = m.build(cls.p, legacy=True)

    def test_old_geometry_has_no_socket_walls(self):
        p = self.p
        iy = _idx(self.ys, p["base_d"] - p["wall_t"] - p["socket_depth"] / 2)
        iz = _idx(self.zs, p["socket_z0"] + p["socket_w"] / 2)
        self.assertEqual(m.run_lengths(self.occ[(self.xs >= 0) & (self.xs <= p["base_w"]), iy, iz], m.PITCH), [])

    def test_old_geometry_sticks_out_past_the_foot(self):
        X = np.meshgrid(self.xs, self.ys, self.zs, indexing="ij")[0]
        self.assertGreater(int((self.occ & (X > self.p["base_w"])).sum()), 0)

    def test_old_geometry_blocks_a_mounting_hole(self):
        p = self.p
        X, Y, Z = np.meshgrid(self.xs, self.ys, self.zs, indexing="ij")
        hx = p["base_w"] / 2 - 25
        column = ((X - hx) ** 2 + (Y - p["base_d"] / 2) ** 2 <= (p["hole_d"] / 2) ** 2) & (Z >= 0) & (Z <= p["base_t"] + 3)
        self.assertGreater(int((self.occ & column).sum()), 0)


if __name__ == "__main__":
    unittest.main()
