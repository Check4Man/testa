"""Run analytical checks and controlled acceptance decision."""
import json
from pathlib import Path
from engineering_checks import calculate, Inputs

out = calculate(Inputs())
Path("engineering_results.json").write_text(json.dumps(out, indent=2))
print("DECISION:", out["decision"])
for name, item in out["checks"].items():
    print(f'{name}: {item["value_MPa" if "value_MPa" in item else "value_mm"]:.4f} / '
          f'{item["allowable_MPa" if "allowable_MPa" in item else "allowable_mm"]:.4f} '
          f'{"PASS" if item["pass"] else "FAIL"}')
print("NEXT ACTION:", out["next_action"])
