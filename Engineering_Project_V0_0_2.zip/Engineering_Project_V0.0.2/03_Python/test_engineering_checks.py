import json
import unittest
from pathlib import Path
from engineering_checks import calculate, Inputs

class EngineeringChecks(unittest.TestCase):
    def test_default_is_held_not_certified(self):
        r = calculate(Inputs())
        self.assertEqual(r["decision"], "HOLD — DATA NOT VERIFIED")
    def test_higher_load_does_not_reduce_beam_stress(self):
        a = calculate(Inputs(load_N=10))
        b = calculate(Inputs(load_N=20))
        self.assertGreater(b["beam"]["stress_MPa"], a["beam"]["stress_MPa"])
    def test_invalid_beam_geometry_rejected(self):
        with self.assertRaises(ValueError):
            calculate(Inputs(beam_outer_mm=20, beam_wall_mm=11))


class GoldenValues(unittest.TestCase):
    """A-03: values from independent hand calculation (see TEST_AUDIT_LOG.md, section 3)."""
    def setUp(self):
        self.r = calculate(Inputs())
    def test_beam_second_moment(self):
        self.assertAlmostEqual(self.r["beam"]["I_mm4"], 7872.0, places=6)
    def test_beam_max_moment(self):
        self.assertAlmostEqual(self.r["beam"]["Mmax_Nmm"], 1000.0, places=6)
    def test_beam_stress(self):
        self.assertAlmostEqual(self.r["beam"]["stress_MPa"], 1.2703252, places=6)
    def test_beam_deflection(self):
        self.assertAlmostEqual(self.r["beam"]["deflection_mm"], 0.02454735, places=7)
    def test_bracket_screen(self):
        b = self.r["bracket_screen"]
        self.assertAlmostEqual(b["reaction_N_each"], 5.0, places=9)
        self.assertAlmostEqual(b["moment_Nmm"], 150.0, places=9)
        self.assertAlmostEqual(b["stress_MPa"], 0.17578125, places=9)
    def test_allowables(self):
        c = self.r["checks"]
        self.assertAlmostEqual(c["beam_bending"]["allowable_MPa"], 120.0)
        self.assertAlmostEqual(c["beam_deflection"]["allowable_mm"], 2.0)
        self.assertAlmostEqual(c["bracket_root_screen"]["allowable_MPa"], 15.0)
    def test_stress_and_deflection_scale_linearly_with_load(self):
        a, b = calculate(Inputs(load_N=10)), calculate(Inputs(load_N=30))
        self.assertAlmostEqual(b["beam"]["stress_MPa"] / a["beam"]["stress_MPa"], 3.0, places=9)
        self.assertAlmostEqual(b["beam"]["deflection_mm"] / a["beam"]["deflection_mm"], 3.0, places=9)
        self.assertAlmostEqual(b["bracket_screen"]["stress_MPa"] / a["bracket_screen"]["stress_MPa"], 3.0, places=9)


class DecisionBranches(unittest.TestCase):
    """A-04: every decision outcome and the pass/fail boundary."""
    VERIFIED = dict(material_data_verified=True, geometry_verified=True)
    def test_fail_on_beam_bending(self):
        r = calculate(Inputs(load_N=2000))
        self.assertFalse(r["checks"]["beam_bending"]["pass"])
        self.assertEqual(r["decision"], "FAIL")
        self.assertTrue(r["next_action"].startswith("REDESIGN"))
    def test_fail_on_deflection_only(self):
        r = calculate(Inputs(beam_E_MPa=300))
        self.assertFalse(r["checks"]["beam_deflection"]["pass"])
        self.assertTrue(r["checks"]["beam_bending"]["pass"])
        self.assertEqual(r["decision"], "FAIL")
    def test_fail_on_bracket_screen_only(self):
        r = calculate(Inputs(bracket_root_thickness_mm=0.3))
        self.assertFalse(r["checks"]["bracket_root_screen"]["pass"])
        self.assertTrue(r["checks"]["beam_bending"]["pass"])
        self.assertEqual(r["decision"], "FAIL")
    def test_pass_only_when_both_flags_verified(self):
        r = calculate(Inputs(**self.VERIFIED))
        self.assertTrue(r["decision"].startswith("ANALYTICAL SCREEN PASS"))
        self.assertIn("FEA", r["next_action"])
    def test_one_flag_is_not_enough(self):
        for flags in (dict(material_data_verified=True), dict(geometry_verified=True)):
            self.assertEqual(calculate(Inputs(**flags))["decision"], "HOLD \u2014 DATA NOT VERIFIED")
    def test_fail_overrides_verified_flags(self):
        self.assertEqual(calculate(Inputs(load_N=2000, **self.VERIFIED))["decision"], "FAIL")
    def test_stress_equal_to_allowable_passes_and_just_above_fails(self):
        sigma = calculate(Inputs())["beam"]["stress_MPa"]
        at_limit = calculate(Inputs(beam_yield_MPa=2 * sigma))     # allowable == stress exactly
        self.assertTrue(at_limit["checks"]["beam_bending"]["pass"])
        over = calculate(Inputs(beam_yield_MPa=2 * sigma * 0.999))
        self.assertFalse(over["checks"]["beam_bending"]["pass"])


class RequirementChecks(unittest.TestCase):
    """Requirement-level tests (REQUIREMENTS.md). Names carry the requirement ID."""
    def test_R05_default_load_is_10N(self):
        self.assertEqual(Inputs().load_N, 10.0)
    def test_R05_default_case_passes_screen_with_margin(self):
        for name, c in calculate(Inputs())["checks"].items():
            value = c.get("value_MPa", c.get("value_mm"))
            allowable = c.get("allowable_MPa", c.get("allowable_mm"))
            self.assertTrue(c["pass"], name)
            self.assertGreaterEqual(allowable / value, 10.0, f"{name}: margin below 10x")
    def test_R01_default_span_is_400mm_assumption(self):
        self.assertEqual(Inputs().span_mm, 400.0)
    def test_R09_shipped_results_json_is_current(self):
        shipped = json.loads((Path(__file__).parent / "engineering_results.json").read_text())
        self.assertEqual(shipped, json.loads(json.dumps(calculate(Inputs()))))


class InputValidation(unittest.TestCase):
    """A-06: bad inputs raise ValueError, never ZeroDivisionError or silent acceptance."""
    def test_non_positive_fields_rejected(self):
        for name in ("span_mm", "beam_outer_mm", "beam_wall_mm", "beam_E_MPa", "beam_yield_MPa",
                     "bracket_E_MPa", "bracket_tensile_MPa", "bracket_width_mm",
                     "bracket_root_thickness_mm", "safety_factor"):
            for bad in (0, -1):
                with self.subTest(field=name, value=bad):
                    with self.assertRaises(ValueError):
                        calculate(Inputs(**{name: bad}))
    def test_negative_load_rejected(self):
        with self.assertRaises(ValueError):
            calculate(Inputs(load_N=-10))
    def test_negative_eccentricity_rejected(self):
        with self.assertRaises(ValueError):
            calculate(Inputs(bracket_load_eccentricity_mm=-1))
    def test_zero_load_is_allowed(self):
        self.assertEqual(calculate(Inputs(load_N=0))["beam"]["stress_MPa"], 0.0)


if __name__ == "__main__":
    unittest.main()
