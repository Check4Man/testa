"""Voxel mirror of 01_CAD/OpenSCAD/bracket_pair.scad (units: mm).

OpenSCAD is not required to run the tests. This module re-implements the SCAD
solid logic in numpy so wall thickness, holes and extents can be checked and
rendered. It is a MIRROR, not the real renderer: keep it in step with the SCAD
file and confirm with a real render (F6) when OpenSCAD is available.

solid()       -> current geometry (V0.0.2)
solid_v000()  -> geometry as written in V0.0.0/V0.0.1, kept to document the
                 defects found in audit entry 001/002 and for before/after renders.
"""
import re
from pathlib import Path

import numpy as np

SCAD_PATH = Path(__file__).resolve().parent.parent / "01_CAD" / "OpenSCAD" / "bracket_pair.scad"
PITCH = 0.4  # voxel size in mm


def load_params(path=SCAD_PATH):
    """Parse top-level `name = expression;` assignments from the SCAD file."""
    params = {}
    for name, expr in re.findall(r"^\s*(\w+)\s*=\s*([^;]+);", Path(path).read_text(), re.M):
        try:
            params[name] = eval(expr, {"__builtins__": {}}, dict(params))
        except Exception:
            pass  # not a plain numeric expression (e.g. $fn handled elsewhere)
    return params


def grid(p, pitch=PITCH, x_max=None):
    """Voxel-centre coordinate arrays covering the part with a small margin."""
    xm = x_max if x_max is not None else p["base_w"] + 5
    xs = np.arange(-2, xm, pitch) + pitch / 2
    ys = np.arange(-2, p["base_d"] + 3, pitch) + pitch / 2
    zs = np.arange(-2, p["base_t"] + p["upright_h"] + 3, pitch) + pitch / 2
    X, Y, Z = np.meshgrid(xs, ys, zs, indexing="ij")
    return (xs, ys, zs), (X, Y, Z)


def _box(X, Y, Z, x0, y0, z0, dx, dy, dz):
    return (X >= x0) & (X <= x0 + dx) & (Y >= y0) & (Y <= y0 + dy) & (Z >= z0) & (Z <= z0 + dz)


def _holes(p, X, Y, Z):
    m = np.zeros_like(X, dtype=bool)
    for hx in (p["base_w"] / 2 - p["hole_spacing"] / 2, p["base_w"] / 2 + p["hole_spacing"] / 2):
        m |= ((X - hx) ** 2 + (Y - p["base_d"] / 2) ** 2 <= (p["hole_d"] / 2) ** 2) & (Z >= -1) & (Z <= p["base_t"] + 1)
    return m


def solid(p, X, Y, Z):
    """Current bracket (V0.0.2): walled socket, YZ-plane gussets, central rib."""
    bw, bd, bt, uh, wt = (p[k] for k in ("base_w", "base_d", "base_t", "upright_h", "wall_t"))
    sw, sd, sww, bw_blk, z0 = (p[k] for k in ("socket_w", "socket_depth", "socket_wall", "block_w", "socket_z0"))
    gt, gr, gh, rib = p["gusset_t"], p["gusset_run"], p["gusset_h"], p["rib_t"]

    u = _box(X, Y, Z, 0, 0, 0, bw, bd, bt)                                       # foot
    u |= _box(X, Y, Z, 0, bd - wt, bt, bw, wt, uh)                               # upright plate
    u |= _box(X, Y, Z, (bw - bw_blk) / 2, bd - wt - sd, z0 - sww, bw_blk, sd, bw_blk)  # socket block
    for xpos in (0, bw - gt):                                                    # side gussets (YZ plane)
        y0 = bd - wt - gr
        u |= _box(X, Y, Z, xpos, y0, bt, gt, gr, gh) & ((Z - bt) <= (Y - y0) * gh / gr)
    u |= _box(X, Y, Z, (bw - rib) / 2, bd - wt - sd, bt, rib, sd, z0 - sww - bt)  # central rib

    u &= ~_holes(p, X, Y, Z)
    u &= ~_box(X, Y, Z, (bw - sw) / 2, bd - wt - sd - 1, z0, sw, sd + wt + 2, sw)  # beam cavity
    return u


def solid_v000(p, X, Y, Z):
    """Bracket as written in V0.0.0/V0.0.1 (defective; documentation only)."""
    bw, bd, bt, uh, wt = (p[k] for k in ("base_w", "base_d", "base_t", "upright_h", "wall_t"))
    sw, sd = p["socket_w"], p["socket_depth"]
    gt, gr, gh = p["gusset_t"], p["gusset_run"], p["gusset_h"]
    zc = bt + uh - sw

    u = _box(X, Y, Z, 0, 0, 0, bw, bd, bt)
    u |= _box(X, Y, Z, 0, bd - wt, bt, bw, wt, uh)
    u |= _box(X, Y, Z, (bw - sw) / 2, bd - wt - sd, zc, sw, sd, sw)              # block, same width as cavity
    for xpos in (0, bw - gt):                                                    # flat wedge in the XY plane
        gx, gy = X - xpos, Y - (bd - wt - gr)
        u |= (gx >= 0) & (gx <= gr) & (gy >= 0) & (gy <= gx * gh / gr) & (Z >= bt) & (Z <= bt + gt)
    u &= ~_holes(p, X, Y, Z)
    u &= ~_box(X, Y, Z, (bw - sw) / 2, bd - wt - sd - 1, zc, sw, sd + wt + 2, sw)
    return u


def build(p=None, legacy=False, pitch=PITCH):
    """Return (axes, occupancy) for the bracket. Legacy needs extra x range for the stray gusset."""
    p = p or load_params()
    axes, (X, Y, Z) = grid(p, pitch, x_max=p["base_w"] + 30 if legacy else None)
    return axes, (solid_v000 if legacy else solid)(p, X, Y, Z)


def run_lengths(mask_1d, step):
    """Lengths (mm) of consecutive True runs along a 1-D boolean array."""
    out, n = [], 0
    for v in mask_1d:
        if v:
            n += 1
        elif n:
            out.append(n * step)
            n = 0
    if n:
        out.append(n * step)
    return out
