# Changelog
## V0.0.2 — Socket fix, stronger tests, pictures
- CAD: bracket socket now has 3 mm printed walls on all four sides (it had 0 mm walls and an open top). Gussets rebuilt as triangular webs in the YZ plane (the old flat wedges overhung the foot by 24 mm and covered a mounting hole). Added a central rib under the socket block. Beam cavity floor is 3 mm lower. **Not yet compiled in OpenSCAD.**
- Code: `validate()` added; bad inputs now raise `ValueError` (previously `ZeroDivisionError` or silent acceptance). Calculation and `engineering_results.json` unchanged.
- Tests: 3 -> 38 (golden values, decision branches, requirement checks, input validation, 13 geometry tests on `scad_mirror.py`). Mutation check: 20 of 20 detectable bugs caught (was 2 of 12), 1 known blind spot.
- Added `03_Python/scad_mirror.py`, `06_Validation/audit_tools/` (`mutation_check.py`, `render_bracket.py`) and `01_CAD/renders/` (3 before/after pictures).
- `requirements.txt` now lists numpy (needed by tests); pytest, matplotlib and scikit-image marked optional.
- Audit entry 002 added to `06_Validation/TEST_AUDIT_LOG.md`.
- Known stale: `04_Report` still describes V0.0.0. Open: A-02 (press fit decision), A-07 (mm or cm), A-08, A-10 to A-13, A-15.
- Status unchanged: HOLD — DATA NOT VERIFIED.

## V0.0.1 — Test audit release (documentation only)
- Added `06_Validation/TEST_AUDIT_LOG.md` (audit entry 001: test run record, mutation test, requirement traceability, CAD finding, actions A-01 to A-15).
- Added `AI_REFERENCE.md` (project layout, requirements, status, working rules).
- Added project layout and log pointer to `README.md`; added test-coverage table to `REQUIREMENTS.md`; added step 7 to `RUN_ME.txt`.
- Removed `__pycache__` from the release. No change to CAD, calculations, tests, BOM, evidence or report.
- Status unchanged: HOLD — DATA NOT VERIFIED. Audit found a socket geometry defect in the SCAD source (see log, section 6).
## V0.0.0 — Initial preliminary package
- Established 200 × 400 mm assembly envelope as an editable assumption.
- Added parametric two-hole bracket concept and 20 × 20 × 2 mm beam assumption.
- Added Python analytical screening and automated pass/fail/next-action logic.
- Added Gmsh mesh-generation starter and CalculiX FEA handoff notes.
- Added BOM, source-evidence register, test plan, and Google Docs-ready report.
- No physical validation or solved FEA is claimed.
