"""Convenience wrapper for Gmsh; requires gmsh executable and bracket.step."""
import shutil, subprocess, sys
from pathlib import Path
if not shutil.which("gmsh"):
    sys.exit("ERROR: gmsh executable not found. Install Gmsh and add it to PATH.")
step = Path(sys.argv[1] if len(sys.argv)>1 else "bracket.step")
if not step.exists():
    sys.exit(f"ERROR: {step} not found. Export STEP from a STEP-capable CAD bridge first.")
subprocess.run(["gmsh", str(step), "-3", "-format", "msh2", "-o", "bracket.msh"], check=True)
print("Created bracket.msh. Confirm physical groups, boundary conditions and mesh quality before solving.")
