// Gmsh starter template. Import a STEP file exported from a STEP-capable CAD tool.
// Run: gmsh bracket.step -3 -format msh2 -o bracket.msh
// For STL generation from a mesh: gmsh bracket.msh -format stl -o bracket_mesh.stl
// For CAD import + mesh generation, use the command above; set mesh size after geometry inspection.
SetFactory("OpenCASCADE");
Merge "bracket.step";
// Global sizing is a starting point only; perform mesh convergence.
Mesh.CharacteristicLengthMin = 1.0;
Mesh.CharacteristicLengthMax = 4.0;
Mesh.Algorithm3D = 10;
