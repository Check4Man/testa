# 3D FEA workflow — Gmsh + CalculiX
1. Export the bracket as STEP using a STEP-capable CAD tool/bridge. OpenSCAD does not natively export STEP.
2. Generate a tetrahedral volume mesh using `python build_mesh.py bracket.step`.
3. Create physical groups for (a) mounting-hole cylindrical faces/bolt constraints, (b) beam-socket contact/load faces, and (c) bracket solid. Inspect element quality.
4. Convert the mesh to CalculiX input format using a validated Gmsh-to-CalculiX exporter or a controlled mesh conversion script. Preserve node/element sets.
5. Define PETG as an orthotropic/anisotropic material if print data are available. An isotropic placeholder is not adequate for final acceptance.
6. Apply realistic bolt constraints and contact or a justified equivalent. Apply 10 N to the beam/socket load path, not an arbitrary point singularity.
7. Run `ccx bracket`. Review displacement, von Mises/principal stress, strain, reaction balance, and contact/bolt bearing.
8. Repeat with at least three systematically refined meshes. Report peak stress away from mathematical singularities and demonstrate convergence of displacement and representative stress.
9. Save solver input, `.dat`, `.frd`, mesh, screenshots, and postprocessing report.

## Required FEA release criteria
- Geometry and boundary conditions reviewed.
- Material card supported by datasheet and print-orientation test data.
- Reaction force sums to applied load within 2%.
- Mesh quality acceptable and convergence documented (target <5% change in representative stress/displacement between final refinements).
- No stress/strain exceeds the appropriate allowables with required safety factor.
- Contact, bolt-hole bearing, and layer orientation assessed.

This folder does not contain a solved result. A real solver run requires the final geometry, verified material model, boundary conditions, and installed solver.
