# Analytical model and assumptions
## Beam
For a simply supported beam with a central point load:
- Maximum moment: Mmax = P L / 4
- Maximum bending stress: sigma = M c / I
- Midspan deflection: delta = P L^3 / (48 E I)
For a square hollow section, I = (B^4 - b^4)/12, with b = B - 2t.

## Bracket screening
The Python script applies a deliberately conservative simplified cantilever screen to each bracket:
- reaction per bracket = P/2
- assumed load eccentricity = 30 mm
- nominal rectangular root section uses width 80 mm and thickness 8 mm
- sigma = M c / I, with I = width × thickness^3 / 12
This does NOT capture local 3D stress concentrations, anisotropic printed strength, contact pressure, bolt bearing, or the gusset's true load path. Treat it as a preliminary gate only.

## Pass/fail policy
The automated gate passes only if every numeric check is below its allowable value and inputs are marked as verified. If material/source data remain provisional, the outcome is `HOLD — DATA NOT VERIFIED`, even if calculated stress is below the provisional allowable. No pass is a certification.
