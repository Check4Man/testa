# Part register and purchasing evidence
## Custom bracket
- Part number: BRK-200-400-V0
- Revision: V0.0.2 (design revision; was V0.0.0)
- Quantity: 2
- CAD source: `01_CAD/OpenSCAD/bracket_pair.scad`
- Geometry: 80 × 50 mm foot, 8 mm nominal base/upright, two Ø5.5 mm mounting holes at 50 mm pitch, provisional 20.4 mm square socket with 3 mm printed walls on all four sides, two side gussets and a central rib (V0.0.2).
- Purchasing: custom manufactured; no commercial part link applies.

## Beam
- Proposed specification: 6061-T6 aluminium square tube, 20 × 20 × 2 mm, 400 mm long.
- This is a material/section selection proposal, not a verified supplier SKU. A supplier product URL and datasheet must be added after choosing a vendor and confirming exact alloy, temper, wall tolerance, straightness, and length.

## Links
No supplier product URLs are invented in V0.0.0. Add only direct product pages and downloadable datasheets that confirm the exact item being purchased.
