# AI reference — read this first

Short orientation for an AI assistant (or a new human) picking up this project. Keep it under one page; update it whenever the layout, requirements or status change.

## What this is
A preliminary design package for **two 3D-printed brackets holding one commercial aluminium square tube** inside a nominal 200 × 400 mm envelope. It contains parametric CAD, Python screening calculations with automated tests, an FEA workflow template, BOM, evidence register, test plan and a report.

**Status: PRELIMINARY CONCEPT. Not released for load-bearing use.** Automated decision at default inputs: `HOLD — DATA NOT VERIFIED`.

## Versions
- **Package version** = the ZIP (currently V0.0.2). **Design revision** = CAD, code and numbers (currently V0.0.2, part `BRK-200-400-V0`). V0.0.1 was documentation only. V0.0.2 changed the CAD, added input validation and tests; calculation results are unchanged from V0.0.0.
- **Stale:** `04_Report/` still describes V0.0.0. **Unconfirmed:** the V0.0.2 SCAD has not been compiled in OpenSCAD (only checked through `03_Python/scad_mirror.py`).
- Never overwrite a released ZIP. A new release is a new complete ZIP and updates `CHANGELOG.md` and the verification status together.

## Layout
```
README.md                  purpose, assumptions, workflow, limitations, layout
AI_REFERENCE.md            this file
REQUIREMENTS.md            requirement IDs R-01..R-10, verification, status, test coverage
CHANGELOG.md               release history
RUN_ME.txt                 quick-start commands
requirements.txt           Python dependencies
01_CAD/OpenSCAD/           bracket_pair.scad  (parametric, mm)
01_CAD/renders/            before/after PNGs (iso view, socket sections, foot top view)
02_Analysis/               analytical_model.md, FEA_WORKFLOW.md, gmsh/ (mesh template + wrapper)
03_Python/                 engineering_checks.py (calc + validate), run_all_checks.py, engineering_results.json,
                           scad_mirror.py (numpy mirror of the SCAD), test_engineering_checks.py, test_cad_geometry.py
04_BOM/                    BOM.csv, PURCHASING_AND_PART_REGISTER.md
04_Report/                 Engineering_Report_Google_Docs_Ready.md / .docx
05_Evidence/               EVIDENCE_REGISTER.md
06_Validation/             TEST_PLAN.md (physical), TEST_AUDIT_LOG.md (automated-test audit + next actions)
06_Validation/audit_tools/ mutation_check.py (injects bugs, confirms tests fail), render_bracket.py (makes the PNGs)
```

## Requirements (summary; full matrix in `REQUIREMENTS.md`)
| ID | Requirement | Interpretation in this package |
|---|---|---|
| R-01 | 200 × 400 (unit unclear) | Assumed mm; **owner to confirm** |
| R-02 | 3D printed brackets | Two identical PETG brackets |
| R-03 | Press fit | 20.4 mm socket for 20 mm tube (currently a clearance, see audit) |
| R-04 | Two-hole mounting | Two Ø5.5 mm holes, 50 mm pitch, per bracket |
| R-05 | Withstand ≥ 10 N | 10 N static, midspan, simply supported |
| R-06 | Commercial beam, known properties | 6061-T6 20×20×2 mm tube (unverified) |
| R-07 | STEP file | Not generated |
| R-08 | 3D FEA | Gmsh + CalculiX template only |
| R-09 | Python calc + automated test | Provided (weak coverage, see audit) |
| R-10 | Google Docs report | DOCX/MD provided |

## Key numbers (all provisional)
Load 10 N · span 400 mm · beam 20×20×2 mm, E 69 GPa, yield 240 MPa · PETG E 1.8 GPa, strength 30 MPa · safety factor 2 · deflection limit L/200 · bracket 80 × 50 mm foot, 8 mm base and upright, 68 mm tall, socket cavity 20.4 mm square with 3 mm walls (cavity floor z = 44.6 mm), two side gussets, central rib.
Units everywhere: N, mm, MPa.

## How to run
```
cd 03_Python
python run_all_checks.py        # prints decision, writes engineering_results.json
python -m unittest -v           # 38 tests; run from this folder (from the root it finds nothing); needs numpy
python ../06_Validation/audit_tools/mutation_check.py   # expect 20 of 20 detectable mutations caught
```
OpenSCAD, Gmsh and CalculiX (`ccx`) are needed for real CAD and FEA steps and are not required for the Python tests. `scad_mirror.py` re-implements the SCAD geometry: **when you edit `bracket_pair.scad`, edit the mirror to match**, then re-render in OpenSCAD.

## Rules for working on this project
1. **Never claim verification that does not exist.** No solved FEA, physical test, STEP file or supplier evidence exists yet. Keep the `HOLD` logic intact unless both verification flags are set with evidence.
2. **Do not invent supplier URLs, datasheet values or part numbers.** Material numbers in the code are placeholders until `05_Evidence/` holds real datasheets.
3. **Keep parameters consistent.** Bracket width and thickness appear in both the SCAD file and `engineering_checks.py` (a test checks this); the SCAD logic is mirrored in `scad_mirror.py`. Change all together and re-run the tests.
4. **Log test work.** After any test or audit session, add a new entry at the top of `06_Validation/TEST_AUDIT_LOG.md` (what ran, results, actions).
5. **Update together:** CHANGELOG, version strings, BOM, CAD, calculations, report and verification status.
6. **Ask, don't guess,** on the open items: mm vs cm (R-01), mounting sketch and hole coordinates, load direction, press fit vs slip fit (R-03).

## Where to look next
Open actions are in `06_Validation/TEST_AUDIT_LOG.md`: entry 002, section 6 (newest) and entry 001, section 7 (A-01 to A-15; A-01, A-03 to A-06, A-09, A-14 are done). First: render the V0.0.2 SCAD in OpenSCAD and confirm it matches `01_CAD/renders/`. Then A-02 (press fit or slip fit) and A-07 (mm or cm), both needing an owner decision, then regenerate the report.
