// Engineering Project V0.0.2 — preliminary parametric bracket (design revision V0.0.2)
// Units: mm. Two identical brackets support one square tube.
// IMPORTANT: concept geometry only; confirm mounting orientation before release.
// V0.0.2: socket now has printed walls on all four sides (socket_wall), gussets are
//         triangular webs in the YZ plane, and a central rib supports the socket block.
//         Not yet compiled in OpenSCAD by the author of this change: render (F6) to confirm.

$fn = 64;
base_w = 80;
base_d = 50;
base_t = 8;
upright_h = 60;
wall_t = 8;
socket_clearance = 0.4; // provisional diametral/side clearance; calibrate by coupon (audit action A-02 open)
beam_outer = 20;
socket_w = beam_outer + socket_clearance;
socket_wall = 3;        // printed wall around the beam cavity; confirm by print test
socket_depth = 30;
block_w = socket_w + 2*socket_wall;                        // outer width and height of socket block
socket_z0 = base_t + upright_h - socket_wall - socket_w;   // cavity floor height
hole_d = 5.5;           // M5 clearance, verify chosen fastener standard
hole_spacing = 50;
gusset_t = 8;
gusset_run = 32;
gusset_h = 32;
rib_t = 8;

// Coordinate convention: base lies in XY; upright at rear edge (Y=base_d-wall_t).
module bracket() {
    difference() {
        union() {
            // mounting foot
            cube([base_w, base_d, base_t]);
            // upright plate
            translate([0, base_d-wall_t, base_t])
                cube([base_w, wall_t, upright_h]);
            // beam socket block on the front of the upright: outer size = cavity + wall on every side
            translate([(base_w-block_w)/2, base_d-wall_t-socket_depth, socket_z0-socket_wall])
                cube([block_w, socket_depth, block_w]);
            // two side gussets: triangular webs standing in the YZ plane, rising towards the upright
            for (xpos=[0, base_w-gusset_t]) {
                translate([xpos, base_d-wall_t-gusset_run, base_t])
                    rotate([90, 0, 90])
                        linear_extrude(height=gusset_t)
                            polygon(points=[[0,0],[gusset_run,0],[gusset_run,gusset_h]]);
            }
            // central rib from the foot up to the underside of the socket block
            translate([(base_w-rib_t)/2, base_d-wall_t-socket_depth, base_t])
                cube([rib_t, socket_depth, socket_z0-socket_wall-base_t]);
        }
        // two mounting holes through base, centred across width
        for (xpos=[base_w/2-hole_spacing/2, base_w/2+hole_spacing/2]) {
            translate([xpos, base_d/2, -1])
                cylinder(h=base_t+2, d=hole_d);
        }
        // square beam cavity: open at the front, through the upright, closed top and bottom by socket_wall
        translate([(base_w-socket_w)/2, base_d-wall_t-socket_depth-1, socket_z0])
            cube([socket_w, socket_depth+wall_t+2, socket_w]);
    }
}

bracket();
