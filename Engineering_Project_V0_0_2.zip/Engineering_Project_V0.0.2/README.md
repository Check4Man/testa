# Engineering Design Project — V0.0.2
Status: PRELIMINARY CONCEPT / NOT RELEASED FOR LOAD-BEARING USE
Package V0.0.2 revises the bracket CAD (socket walls, gussets, rib), adds input validation and 38 automated tests, and adds before/after pictures. The report in `04_Report/` still describes V0.0.0 and is due for regeneration. The new SCAD has not yet been compiled in OpenSCAD: render it (F6) first.

## Purpose
A reproducible starter design package for a 200 mm × 400 mm assembly using two 3D-printed mounting brackets and a commercially sourced beam. The package contains parametric OpenSCAD CAD, Python beam/bracket screening calculations, automated pass/fail checks, a Gmsh meshing template, a CalculiX handoff template, test planning, BOM, and a Google Docs-ready report.

## Project layout
```
README.md                  this file
AI_REFERENCE.md            one-page orientation for AI assistants and new contributors
REQUIREMENTS.md            requirements R-01..R-10, verification status, test coverage
CHANGELOG.md               release history
RUN_ME.txt                 quick-start commands
requirements.txt           Python dependencies
01_CAD/OpenSCAD/           bracket_pair.scad
01_CAD/renders/            01_bracket_before_after_iso.png, 02_socket_sections_before_after.png, 03_foot_top_view_before_after.png
02_Analysis/               analytical_model.md, FEA_WORKFLOW.md, gmsh/ (build_mesh.py, bracket_mesh.geo)
03_Python/                 engineering_checks.py, run_all_checks.py, engineering_results.json
                           scad_mirror.py (numpy mirror of the SCAD geometry)
                           test_engineering_checks.py (25 tests), test_cad_geometry.py (13 tests)
04_BOM/                    BOM.csv, PURCHASING_AND_PART_REGISTER.md
04_Report/                 Engineering_Report_Google_Docs_Ready.md / .docx  (stale: describes V0.0.0)
05_Evidence/               EVIDENCE_REGISTER.md
06_Validation/             TEST_PLAN.md, TEST_AUDIT_LOG.md
06_Validation/audit_tools/ mutation_check.py, render_bracket.py
```
Test and audit history, with next-iteration actions, is kept in `06_Validation/TEST_AUDIT_LOG.md` (newest entry first).

## Critical interpretation assumptions
The user has not yet supplied a sketch or mounting-hole coordinates. V0.0.0 therefore uses explicit, editable assumptions:
- Assembly envelope: 200 mm wide × 400 mm long.
- Two identical end brackets support one 400 mm long, 20 × 20 × 2 mm aluminium square tube.
- Two M5 mounting holes per bracket, 50 mm centre-to-centre.
- Load case for initial screening: 10 N downward at beam midspan; simply supported beam.
- Bracket concept: 8 mm nominal printed base and upright, 20.4 mm square beam socket, two M5 clearance holes, and triangular gusset.
- Printed bracket material default: PETG, provisional E = 1,800 MPa and tensile strength = 30 MPa. These are placeholder design inputs, NOT certified values. Replace with the selected filament manufacturer's datasheet and print-orientation coupon data.
- Beam default: 6061-T6 aluminium square tube 20 × 20 × 2 mm. Verify actual supplier dimensions, alloy/temper, wall thickness, and mechanical-property datasheet before purchase.

These assumptions are not evidence that the user's unspecified mounting arrangement is satisfied. Confirm geometry and load direction before design freeze.

## Software workflow
1. Open `01_CAD/OpenSCAD/bracket_pair.scad` in OpenSCAD. Render (F6), export STL for each part, and export STEP only through a validated STEP-capable CAD bridge (OpenSCAD itself does not natively export STEP).
2. Use `02_Analysis/gmsh/build_mesh.py` or the included `.geo` template to generate a mesh from a STEP file. Gmsh also supports STL output; the OpenSCAD STL export is the simplest initial route.
3. Run `03_Python/run_all_checks.py` for the transparent analytical checks and decision report. Run the tests from `03_Python/` with `python -m unittest -v` (needs numpy). `06_Validation/audit_tools/mutation_check.py` confirms the tests catch injected bugs; `render_bracket.py` regenerates the pictures in `01_CAD/renders/`.
4. For true 3D solid FEA, install Gmsh and CalculiX (`ccx`). Convert the bracket STEP to a Gmsh mesh, create solver input with the documented boundary/load sets, solve, and inspect the `.frd` results in a compatible postprocessor. The supplied FEA folder is a workflow template, not a completed solved FEA result.
5. Import `04_Report/Engineering_Report_Google_Docs_Ready.docx` into Google Docs, or copy its Markdown source. Google Docs access is not connected from this package.

## Known limitations
- No physical test has been performed.
- No mesh convergence study or solved FEA result is claimed.
- Analytical bracket screening uses a simplified cantilever model; it is not a substitute for local stress analysis at holes, fillets, socket corners, layer interfaces, or contact regions.
- Beam deflection and stress are screened using elementary beam theory.
- Press-fit interference must be calibrated against the actual printer, material, orientation, and measured beam dimensions.
- The 10 N requirement is interpreted as a static downward midspan load. Dynamic, impact, fatigue, off-axis, and misuse loads are not included.

## Versioning
Package version (the ZIP) and design revision (CAD, calculations, part `BRK-200-400-V0`) are tracked separately. V0.0.1 changed documentation only. V0.0.2 changed the CAD (design revision V0.0.2); the calculation results are unchanged from V0.0.0.
Each release is a complete standalone ZIP. Never overwrite a prior release. Update `CHANGELOG.md`, version strings, BOM, CAD, calculations, and verification status together.
