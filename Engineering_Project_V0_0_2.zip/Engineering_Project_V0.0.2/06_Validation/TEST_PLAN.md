# Verification and physical test plan
1. Inspect printed parts for cracks, voids, warping, and dimensional conformity.
2. Measure socket and beam dimensions at multiple locations. Record actual interference/clearance.
3. Perform fit coupons at several socket clearances before printing final brackets.
4. Mount the assembly using the specified two-hole arrangement and intended fasteners.
5. Apply a calibrated 10 N downward load at the defined location gradually; hold for 60 seconds.
6. Record load, displacement, permanent set, cracking, socket slip, and fastener movement.
7. Remove load and inspect. Repeat at least three times on separate specimens for preliminary repeatability.
8. Acceptance: no fracture, disengagement, visible damage, fastener pull-through, or permanent deformation beyond a project-defined tolerance. Set that tolerance before testing.
9. Never test over people or fragile equipment. Use guarding and a controlled fixture.

A proof test does not establish fatigue life or performance under impact/dynamic loading.
