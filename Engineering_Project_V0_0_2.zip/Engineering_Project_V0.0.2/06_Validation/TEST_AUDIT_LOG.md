# Test audit log

Append-only. Newest entry at the top. Entries are never edited after the fact; corrections go in a later entry. Each entry records what was run, what was found, and what the next iteration must do. Nothing in this log certifies the design; it audits the **tests and checks**.

---

## Entry 002 — 2026-11-19 — V0.0.2: socket fix and stronger tests (actions A-01 to A-06)

**Auditor:** Claude (automated change and review) · **Environment:** Python 3.12.3 with numpy, matplotlib, scikit-image; no OpenSCAD, Gmsh, CalculiX or pytest.

### 1. Verdict

| Question | Answer | Basis |
|---|---|---|
| Do all tests run? | **YES** | 38 of 38 pass with `python -m unittest` from `03_Python/` (25 in `test_engineering_checks.py`, 13 in `test_cad_geometry.py`). pytest still not run. |
| Do they catch wrong code? | **YES, mostly** | Mutation score 20 of 20 detectable bugs caught (entry 001: 2 of 12). 1 known blind spot, see section 4. |
| Is the new CAD correct? | **NOT CONFIRMED** | Checked only through the Python mirror. The SCAD file has **not been compiled in OpenSCAD**. Render it (F6) before trusting it. |
| Is the design ready? | **NO** | Decision stays `HOLD — DATA NOT VERIFIED`. Evidence, FEA and physical test are still open. |

### 2. New finding (missing from entry 001): the old gussets were also wrong

Measured with the mirror on the V0.0.1 geometry:
- The two "gussets" were flat wedges lying in the XY plane on top of the foot, not webs standing between foot and upright.
- The right wedge extended to x = 103.8 mm, **24 mm beyond the 80 mm foot**.
- The left wedge filled about 53% of the mounting-hole column above the foot (1309 of 2465 voxels at z 9–16 mm).

Pictures: `01_CAD/renders/03_foot_top_view_before_after.png`.

### 3. What changed in the design (revision V0.0.2) — owner review needed

| Change | Why | Effect to check |
|---|---|---|
| `socket_wall = 3` mm; block outer = cavity + 2 × wall; top bridge kept | A-01: socket had 0 mm walls and an open top | Cavity floor moved 3 mm lower (beam centre z = 54.8, was 57.8). Min wall is a guess for FDM; confirm by print test. |
| Gussets rebuilt as triangular webs in the YZ plane | Old wedges overhung the foot and blocked a hole | Check print orientation and overhang. |
| Added a central rib (8 mm wide) under the socket block | The block would otherwise hang 30 mm out in the air | **New design element, not requested.** Remove if you prefer another support. |
| `socket_clearance` left at +0.4 mm | A-02 needs your decision (press fit or slip fit) | Still a clearance fit. |

Python model inputs are unchanged, so `engineering_results.json` is identical to V0.0.0. The 30 mm load eccentricity still does not come from the CAD (A-08 open).

### 4. Tests and checks added

| Action | Result |
|---|---|
| A-03 golden values | Done: `GoldenValues` (7 tests) pins I, M, stress, deflection, bracket screen, allowables, linear scaling. |
| A-04 decision branches | Done: `DecisionBranches` (7 tests): three FAIL paths, PASS only with both flags, one flag not enough, FAIL overrides flags, boundary at allowable. |
| A-05 requirement tests | Done: `RequirementChecks` (4 tests): default load is 10 N, 10x margin at default, 400 mm span, shipped results JSON is current. |
| A-06 input validation | Done: `validate()` raises `ValueError` for non-positive span, section, moduli, strengths, safety factor, width, thickness; negative load or eccentricity. Zero load allowed. |
| A-09 hole checks | Done in `test_cad_geometry.py`: two holes at 50 mm pitch, open through the foot, not blocked above it, edge distance at least 2 diameters. |
| A-08 (partial) | `Inputs` foot width and thickness are tested against `base_w` and `base_t` in the SCAD file. Eccentricity still open. |
| A-14 | Done: `06_Validation/audit_tools/mutation_check.py` and `render_bracket.py` are in the package and run from any folder. |
| Geometry tests | Socket walls both sides, top and bottom, cavity clear through full depth, nothing outside the foot, height within the upright top. Three more tests confirm the **old** geometry fails them, so they are not vacuous. |

Mutation check (`audit_tools/mutation_check.py`): 20 bugs injected (14 in the calculation, 6 in SCAD parameters), **20 caught**.
**Known blind spot:** an edit to the SCAD *construction code* (for example making the socket block too short so the cavity is open at the top) is invisible to the Python mirror. Only a real OpenSCAD render test (A-13) can catch it. The mirror must be kept in step with the SCAD by hand.

### 5. Requirement traceability (updated)

| ID | Automated test today | Remaining gap |
|---|---|---|
| R-01 | span default only | Envelope check and mm/cm decision (A-07) |
| R-02 | 10 geometry tests on the mirror | Real OpenSCAD render, STL check (A-13) |
| R-03 | cavity width sanity only | Press fit or slip fit decision (A-02) |
| R-04 | hole count, pitch, clearance, edge distance | none for the model; physical fit is a test-plan item |
| R-05 | default load, 10x margin, golden values | FEA and physical proof test |
| R-06 | none | Evidence in `05_Evidence/` |
| R-07 | none | STEP not generated |
| R-08 | none | `build_mesh.py` error-path tests (A-12), FEA |
| R-09 | 25 calculation tests | none beyond A-11 |
| R-10 | none (manual check in entry 001) | Report is stale, see section 6 |

### 6. Open items after V0.0.2

| # | Item | Note |
|---|---|---|
| A-02 | Press fit vs slip fit | **Needs your decision** |
| A-07 | Envelope check, mm vs cm | **Needs your answer** |
| A-08 | Derive or justify 30 mm eccentricity | CAD socket centre is now about 47 mm above the foot top |
| A-10 | Runner story | Tests still run only from `03_Python/`; `requirements.txt` now lists numpy and marks pytest optional |
| A-11 | Decision constants instead of strings | open |
| A-12 | `build_mesh.py` error-path tests | open |
| A-13 | OpenSCAD smoke test | needs OpenSCAD |
| A-15 | `.gitignore`; duplicate `04_` prefix | open |
| New | Regenerate `04_Report` (still describes V0.0.0 geometry and version) | open |
| New | Confirm V0.0.2 SCAD compiles and renders in OpenSCAD | open, first thing to do |

### 7. Limits of this entry
- All geometry results and pictures come from a Python re-implementation of the SCAD logic at 0.4 mm voxels (0.8 mm for the 3D view), not from OpenSCAD.
- Wall thickness values are quantised to one voxel (0.4 mm); tests allow that tolerance.
- No structural, FEA, material or print validation was done.

---

## Entry 001 — 2026-11-17 — audit of V0.0.0 (released as package V0.0.1)

**Auditor:** Claude (automated review) · **Scope:** `03_Python` test suite, calculation correctness, requirement coverage, CAD source, package hygiene
**Environment:** Python 3.12.3, Linux sandbox, no network. OpenSCAD, Gmsh, CalculiX and pytest were **not installed**, so nothing that needs them was run.

### 1. Verdict

| Question | Answer | Basis |
|---|---|---|
| Are all tests running? | **YES, with caveats** | 3 of 3 `unittest` tests pass. They must be run from `03_Python/`; from the project root `unittest discover` finds 0 tests. `pytest` was not run (not installed). |
| Are they functional? | **PARTLY** | The calculation is correct (matches hand calculation). But the suite caught only **2 of 12** deliberately injected bugs (§4). |
| Do they test the requirements? | **NO** | No automated test exists for R-01 to R-04, R-06 to R-08 or R-10. R-05 (10 N) is only touched indirectly (§5). |
| Is the design ready? | **NO** | CAD socket has a geometry defect (§6). Release status stays `HOLD — DATA NOT VERIFIED`. |

### 2. Test run record

Command (from `03_Python/`): `python3 -m unittest -v`

```
test_default_is_held_not_certified ... ok
test_higher_load_does_not_reduce_beam_stress ... ok
test_invalid_beam_geometry_rejected ... ok
Ran 3 tests in 0.001s   OK
```

| Run | Result |
|---|---|
| `python3 -m unittest -v` in `03_Python/` | 3 passed |
| `python3 -m unittest discover` in project root | **0 tests ran** |
| `python3 -m pytest` | not run (module not installed, no network) |
| `python3 run_all_checks.py` | exit 0; output identical to shipped `engineering_results.json` |
| `python3 03_Python/run_all_checks.py` from project root | runs, but writes `engineering_results.json` into the **current directory**, not `03_Python/` |

### 3. Calculation check (independent hand calculation)

| Quantity | Hand calc | Script | Match |
|---|---|---|---|
| I, 20×20×2 tube | 7872 mm⁴ | 7872 | yes |
| Max moment PL/4 | 1000 N·mm | 1000 | yes |
| Beam stress | 1.2703 MPa | 1.2703 | yes |
| Midspan deflection | 0.02455 mm | 0.02455 | yes |
| Bracket root stress | 0.17578 MPa | 0.17578 | yes |

Margins at 10 N: beam bending 94×, deflection 81×, bracket screen 85×. At default inputs all three checks first fail between 500 N and 1000 N. **The analytical gate cannot discriminate at 10 N**; the real risks (socket retention, hole bearing, layer strength) are not modelled.

Untested branches, exercised manually and behaving as designed: `FAIL` (load 2000 N), `ANALYTICAL SCREEN PASS...` (both verification flags true), `HOLD` default.
Input-validation gaps found manually: `safety_factor=0`, `beam_E_MPa=0`, `bracket_root_thickness_mm=0` raise `ZeroDivisionError`; `load_N=-10` and `load_N=0` are silently accepted.

### 4. Mutation test (are the tests able to fail?)

12 bugs were injected one at a time into a copy of `engineering_checks.py` and the suite re-run.

| Injected bug | Result |
|---|---|
| I formula `/12` → `/10` | SURVIVED |
| Max moment `PL/4` → `PL/8` | SURVIVED |
| Deflection `48` → `24` | SURVIVED |
| Beam allowable ignores safety factor | SURVIVED |
| Bracket allowable ×10 | SURVIVED |
| Deflection limit `L/200` → `L/20` | SURVIVED |
| `FAIL` branch removed | SURVIVED |
| Bracket moment arm 30 → 3 mm | SURVIVED |
| Default load 10 N → 1 N | SURVIVED |
| Default span 400 → 100 mm | SURVIVED |
| Pass comparison inverted | caught |
| `HOLD` branch removed | caught |

**Score: 2 / 12 caught.** The three existing tests check the decision string, a monotonic trend, and one validation error. None pins a numeric value, so wrong physics can ship with a green suite.

### 5. Requirement traceability

| ID | Requirement | Automated test today | Gap |
|---|---|---|---|
| R-01 | 200 × 400 (mm or cm?) | none | No envelope check despite "CAD envelope check" being the stated verification. Unit still unresolved. |
| R-02 | 3D printed brackets | none | SCAD never rendered or tested. Defect found (§6). |
| R-03 | Press fit | none | Design has **+0.4 mm clearance**, which is a slip fit, not a press fit. |
| R-04 | Two-hole mounting | none | Hole count, pitch and edge distance are checkable from the SCAD parameters. |
| R-05 | Withstand ≥ 10 N | indirect | No test asserts the default load is 10 N (mutation "10 N → 1 N" survived) or that the 10 N case passes. |
| R-06 | Commercial beam, known properties | none | Properties are placeholders; only the HOLD test guards against treating them as verified. |
| R-07 | STEP file | none | Not generated. |
| R-08 | 3D FEA | none | Template only. `build_mesh.py` error paths are testable without Gmsh. |
| R-09 | Python calc + automated test | exists | Weak, see §4. |
| R-10 | Google Docs report | none (manual check only) | DOCX opens, and 6 key strings match the Markdown source. Not automated. |

What the current tests do protect: `test_default_is_held_not_certified` guards the "never certify unverified data" policy, which is worth keeping.

### 6. Other findings

**CAD defect (high).** `bracket_pair.scad` unions a socket block of width `socket_w` and then cuts a cavity of the same `socket_w`, so the block leaves **0 mm of wall**. The cavity top is also coplanar with the top of the upright, so the socket is **open at the top**. Effective result: a slot through an 8 mm plate, not a 30 mm deep captured socket. Found with a point-sampling mirror of the SCAD (parameters parsed from the file); OpenSCAD was not available, so **confirm by rendering (F6)**.

**Hygiene (low).**
- `requirements.txt` lists `pytest`, but tests and `RUN_ME.txt` use `unittest`.
- Release ZIP shipped `__pycache__/*.cpython-313.pyc` (removed in V0.0.1).
- Two folders share the `04_` prefix (`04_BOM`, `04_Report`). Not renamed in V0.0.1 to keep paths stable.
- `bracket_width_mm=80` and `bracket_root_thickness_mm=8` are hard-coded in Python and again in the SCAD; the 30 mm load eccentricity is not derived from the CAD (socket centre is about 50 mm above the foot top).
- Decisions are compared as strings containing an em dash; brittle.
- `calculate(x=Inputs())` uses a shared default instance; harmless today, fragile if mutated.

### 7. Actions for the next iteration

Priority order. Each has an acceptance check.

| # | Action | Acceptance |
|---|---|---|
| A-01 | Fix the socket: outer block = `socket_w + 2×wall`, add a top bridge, choose and record a minimum wall (typically 2.4–3 mm for FDM; your call). | F6 render shows closed walls on 4 sides over the full socket depth; STL bounding box matches parameters. |
| A-02 | Decide R-03: true interference press fit (set clearance from coupon results) **or** reword to "slip fit with retention" and add a retention feature. | `REQUIREMENTS.md` wording and `socket_clearance` agree. |
| A-03 | Add golden-value tests with `assertAlmostEqual`: I = 7872, σ = 1.2703, δ = 0.02455, bracket σ = 0.17578. | Mutation score ≥ 10 / 12. |
| A-04 | Add decision-branch tests: FAIL, PASS (flags true), boundary where stress equals allowable. | All three decision strings asserted. |
| A-05 | Add a requirement test `test_R05_default_load_is_10N`, and a R-05 margin test. | Fails if default load or load direction changes. |
| A-06 | Validate inputs: reject `safety_factor ≤ 0`, `E ≤ 0`, non-positive thickness, negative load. | Tests assert `ValueError`, not `ZeroDivisionError`. |
| A-07 | Add R-01 envelope check computed from SCAD parameters. Ask the owner: **mm or cm?** | Test asserts footprint + beam length within the confirmed envelope. |
| A-08 | Single source of truth for geometry: a test that parses the SCAD and compares with `Inputs`, or one shared parameter file. Derive or justify the 30 mm eccentricity. | Changing `base_w` in the SCAD fails a test until Python is updated. |
| A-09 | Add R-04 checks from SCAD parameters (hole count, pitch 50 mm, edge distance ≥ 2× hole diameter). | Passing today; fails if pitch changes. |
| A-10 | Fix runner story: remove `pytest` from `requirements.txt` or document it; make `run_all_checks.py` write next to itself; make tests discoverable from the root. | `unittest` and `pytest` both find 3+ tests from the root. |
| A-11 | Replace decision strings with constants or an Enum. | Tests import the constant. |
| A-12 | Add tests for `build_mesh.py` error paths (missing gmsh, missing STEP) that need no Gmsh. | Both exit with non-zero status and a clear message. |
| A-13 | Add a CAD smoke test when OpenSCAD is available (`openscad -o` exit 0, manifold STL). | Skipped cleanly if OpenSCAD is absent. |
| A-14 | Commit the mutation-check and geometry-mirror scripts used here so Entry 002 can be reproduced. | Scripts live in `06_Validation/` and run from any directory. |
| A-15 | Add a `.gitignore` for `__pycache__/`; renumber the duplicate `04_` folder when paths can change. | No `.pyc` in the next ZIP. |

Where engineering effort should go: because margins at 10 N are about 80–90×, the analytical bracket and beam checks are unlikely to be limiting. Spend effort on socket retention, hole bearing, printed-layer strength (coupons) and the solved 3D FEA.

### 8. Limits of this audit
- OpenSCAD, Gmsh, CalculiX and pytest were unavailable; those paths are unverified, not passed.
- The CAD finding comes from a re-implementation of the SCAD logic, not a render.
- Material values (6061-T6, PETG) remain provisional and were not checked against any datasheet.
- Design, code and tests are **byte-identical** to V0.0.0 apart from the documentation edits listed in `CHANGELOG.md`.
