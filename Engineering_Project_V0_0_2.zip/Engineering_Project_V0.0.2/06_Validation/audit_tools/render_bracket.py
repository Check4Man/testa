"""Render before/after pictures of the bracket from the Python voxel mirror (no OpenSCAD needed).

Run from anywhere:  python 06_Validation/audit_tools/render_bracket.py
Writes PNGs to 01_CAD/renders/.  These show the MIRROR of the SCAD logic; confirm with a real OpenSCAD render.
"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Circle, Rectangle
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from skimage import measure

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "03_Python"))
import scad_mirror as m  # noqa: E402

OUT = ROOT / "01_CAD" / "renders"
OUT.mkdir(parents=True, exist_ok=True)
INK, MUTED, BAD, GOOD, METAL = "#1f2a33", "#5d6b76", "#b3402a", "#1f6f5c", "#8fa3b3"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "text.color": INK,
                     "axes.labelcolor": INK, "axes.edgecolor": MUTED})


def surface(occ, axes, pitch):
    pad = np.pad(occ.astype(np.float32), 1)
    verts, faces, _, _ = measure.marching_cubes(pad, 0.5, spacing=(pitch,) * 3)
    verts -= pitch
    verts += np.array([axes[0][0], axes[1][0], axes[2][0]]) - pitch / 2 + pitch
    return verts, faces


def draw_iso(ax, occ, axes, pitch, title, colour):
    v, f = surface(occ, axes, pitch)
    tris = v[f]
    n = -np.cross(tris[:, 1] - tris[:, 0], tris[:, 2] - tris[:, 0])   # marching cubes winds inwards: flip to outward
    n /= np.linalg.norm(n, axis=1, keepdims=True) + 1e-12
    light = np.array([-0.5, -0.65, 0.6]); light /= np.linalg.norm(light)
    depth = tris[:, :, 1].mean(axis=1)                                  # nearer to the camera (small Y) = lighter
    shade = (0.45 + 0.55 * np.clip(n @ light, 0, 1)) * (1.08 - 0.45 * np.clip(depth / 55.0, 0, 1))
    base = np.array(matplotlib.colors.to_rgb(colour))
    fc = np.clip(shade[:, None] * base, 0, 1)
    pc = Poly3DCollection(tris, facecolors=fc, edgecolors=fc, linewidths=0.25)  # edge = face colour hides seams
    ax.add_collection3d(pc)
    ax.set_xlim(-2, 106); ax.set_ylim(-2, 54); ax.set_zlim(0, 70)
    ax.set_box_aspect((108, 56, 70))
    ax.view_init(elev=24, azim=-58)
    ax.set_xlabel("X (mm)"); ax.set_ylabel("Y (mm)"); ax.set_zlabel("Z (mm)")
    ax.set_title(title, loc="left", fontsize=11, fontweight="bold")
    ax.tick_params(labelsize=8, colors=MUTED)
    for a in (ax.xaxis, ax.yaxis, ax.zaxis):
        a.pane.set_facecolor((1, 1, 1, 0)); a.pane.set_edgecolor("#d5dce1")


def idx(axis, value):
    return int(np.argmin(abs(axis - value)))


def main():
    p = m.load_params()
    old_axes, old = m.build(p, legacy=True, pitch=0.4)
    new_axes, new = m.build(p, legacy=False, pitch=0.4)
    (ox, oy, oz), (nx, ny, nz) = old_axes, new_axes

    # 1. isometric before / after (coarser voxels for speed)
    oa, oo = m.build(p, legacy=True, pitch=0.8)
    na, no = m.build(p, legacy=False, pitch=0.8)
    fig = plt.figure(figsize=(13, 5.6))
    draw_iso(fig.add_subplot(121, projection="3d"), oo, oa, 0.8, "Before (V0.0.0 / V0.0.1)", "#d99a86")
    draw_iso(fig.add_subplot(122, projection="3d"), no, na, 0.8, "After (V0.0.2)", "#86b0cc")
    fig.suptitle("Bracket geometry, rendered from the Python mirror of the SCAD file", x=0.02, ha="left", fontsize=12)
    fig.tight_layout(); fig.savefig(OUT / "01_bracket_before_after_iso.png", dpi=120); plt.close(fig)

    # 2. socket sections (XZ plane) through upright plate and through socket block
    bw, bd, bt, wt = p["base_w"], p["base_d"], p["base_t"], p["wall_t"]
    y_plate, y_block = bd - wt / 2, bd - wt - p["socket_depth"] / 2
    z_old = bt + p["upright_h"] - p["socket_w"]
    cases = [("Before", old_axes, old, z_old), ("After", new_axes, new, p["socket_z0"])]
    fig, axs = plt.subplots(2, 2, figsize=(11, 9.2))
    for r, (name, (xs, ys, zs), occ, zc) in enumerate(cases):
        for c, (yy, label) in enumerate(((y_plate, "through the upright plate"), (y_block, "through the socket block"))):
            ax = axs[r, c]
            sl = occ[:, idx(ys, yy), :].T
            ax.imshow(np.where(sl, 1.0, np.nan), origin="lower", cmap=matplotlib.colors.ListedColormap([METAL]),
                      extent=(xs[0] - .2, xs[-1] + .2, zs[0] - .2, zs[-1] + .2), vmin=0, vmax=1, interpolation="nearest")
            ax.add_patch(Rectangle((bw / 2 - p["beam_outer"] / 2, zc + p["socket_w"] / 2 - p["beam_outer"] / 2),
                                   p["beam_outer"], p["beam_outer"], fill=False, ec=BAD, lw=1.6, ls="--"))
            ax.set_xlim(14, 66); ax.set_ylim(30, 72); ax.set_aspect("equal")
            ax.set_title(f"{name}: {label} (y = {yy:.0f} mm)", loc="left", fontsize=10, fontweight="bold")
            ax.set_xlabel("X (mm)"); ax.set_ylabel("Z (mm)")
            ax.axhline(bt + p["upright_h"], color=MUTED, lw=0.8, ls=":")
            ax.text(15, bt + p["upright_h"] + .8, "top of upright", fontsize=8, color=MUTED)
            for s in ("top", "right"):
                ax.spines[s].set_visible(False)
        if r == 0:
            axs[r, 0].annotate("slot open at the top:\nno wall above the tube", (40, 69), (18, 44), fontsize=9, color=BAD,
                               arrowprops=dict(arrowstyle="->", color=BAD))
            axs[r, 1].text(40, 51, "empty: the block was cut away,\nso nothing holds the tube here", ha="center", fontsize=9, color=BAD)
        else:
            axs[r, 0].annotate(f"{p['socket_wall']:g} mm top wall", (40, 66.5), (46, 70.5), fontsize=9, color=GOOD,
                               arrowprops=dict(arrowstyle="->", color=GOOD))
            axs[r, 1].annotate(f"{p['socket_wall']:g} mm wall on all four sides", (bw / 2 - p["block_w"] / 2 + 1.5, 52), (14.5, 36.5),
                               fontsize=9, color=GOOD, arrowprops=dict(arrowstyle="->", color=GOOD))
    fig.text(0.02, 0.005, f"Dashed outline: {p['beam_outer']:g} x {p['beam_outer']:g} mm tube. Cavity {p['socket_w']:g} mm square (0.4 mm clearance).",
             fontsize=9, color=MUTED)
    fig.tight_layout(rect=(0, 0.02, 1, 1)); fig.savefig(OUT / "02_socket_sections_before_after.png", dpi=120); plt.close(fig)

    # 3. top view of the foot: height map, hole circles, footprint outline
    fig, axs = plt.subplots(1, 2, figsize=(13, 4.6), sharey=True)
    for ax, (name, (xs, ys, zs), occ) in zip(axs, (("Before", old_axes, old), ("After", new_axes, new))):
        z_top = np.where(occ.any(axis=2), (occ * zs[None, None, :]).max(axis=2), np.nan)
        im = ax.imshow(z_top.T, origin="lower", cmap="cividis", vmin=0, vmax=70,
                       extent=(xs[0] - .2, xs[-1] + .2, ys[0] - .2, ys[-1] + .2), interpolation="nearest")
        ax.add_patch(Rectangle((0, 0), bw, bd, fill=False, ec=INK, lw=1.4, ls="--"))
        for hx in (bw / 2 - 25, bw / 2 + 25):
            ax.add_patch(Circle((hx, bd / 2), p["hole_d"] / 2, fill=False, ec="white", lw=1.5))
        ax.set_xlim(-3, 108); ax.set_ylim(-3, 64); ax.set_aspect("equal")
        ax.set_title(f"{name}: top view, colour = height", loc="left", fontsize=11, fontweight="bold")
        ax.set_xlabel("X (mm)")
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
    axs[0].set_ylabel("Y (mm)")
    axs[0].annotate("right gusset sticks out\n24 mm past the foot", (96, 27), (83, 3), fontsize=9, color=BAD,
                    arrowprops=dict(arrowstyle="->", color=BAD))
    axs[0].annotate("left gusset covers\npart of this hole", (15, 27.5), (1, 56), fontsize=9, color=BAD,
                    arrowprops=dict(arrowstyle="->", color=BAD))
    axs[1].text(82.5, 22, "all inside the\nfoot outline;\nholes clear", fontsize=9, color=GOOD)
    fig.colorbar(im, ax=axs, shrink=0.8, label="height (mm)", pad=0.02)
    fig.text(0.01, 0.01, "Dashed rectangle: 80 x 50 mm foot. White circles: the two 5.5 mm mounting holes.", fontsize=9, color=MUTED)
    fig.savefig(OUT / "03_foot_top_view_before_after.png", dpi=120, bbox_inches="tight"); plt.close(fig)
    for f in sorted(OUT.glob("*.png")):
        print(f.name, f.stat().st_size // 1024, "KB")


if __name__ == "__main__":
    main()
