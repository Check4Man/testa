"""Mutation check: inject known bugs into a temporary copy of the package and confirm the test suite fails.

Run from anywhere:  python 06_Validation/audit_tools/mutation_check.py
A mutation that SURVIVES means no test notices that bug. Target: every mutation caught.
Exit code 0 if all caught, 1 otherwise.
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PY = "03_Python/engineering_checks.py"
SCAD = "01_CAD/OpenSCAD/bracket_pair.scad"

MUTATIONS = [
    # (label, file, old, new)
    ("I formula /12 -> /10", PY, "/12.0\n    M = P*L/4.0", "/10.0\n    M = P*L/4.0"),
    ("max moment PL/4 -> PL/8", PY, "M = P*L/4.0", "M = P*L/8.0"),
    ("deflection 48 -> 24", PY, "(48*x.beam_E_MPa*I)", "(24*x.beam_E_MPa*I)"),
    ("beam allowable ignores safety factor", PY, "x.beam_yield_MPa/x.safety_factor", "x.beam_yield_MPa"),
    ("bracket allowable x10", PY, "x.bracket_tensile_MPa/x.safety_factor", "x.bracket_tensile_MPa*10"),
    ("pass comparison inverted", PY, '"pass": sigma_beam <= beam_allow', '"pass": sigma_beam >= beam_allow'),
    ("deflection limit L/200 -> L/20", PY, 'L/200,\n                            "pass": delta <= L/200', 'L/20,\n                            "pass": delta <= L/20'),
    ("HOLD branch removed", PY, "elif not verified:", "elif False:"),
    ("FAIL branch removed", PY, "if not numeric_pass:", "if False:"),
    ("bracket moment arm 30 -> 3 mm", PY, "bracket_load_eccentricity_mm: float = 30.0", "bracket_load_eccentricity_mm: float = 3.0"),
    ("default load 10 -> 1 N", PY, "load_N: float = 10.0", "load_N: float = 1.0"),
    ("default span 400 -> 100 mm", PY, "span_mm: float = 400.0", "span_mm: float = 100.0"),
    ("input validation removed", PY, "    validate(x)\n    P,L,B,t", "    P,L,B,t"),
    ("negative load accepted", PY, "if x.load_N < 0:", "if x.load_N < -1e12:"),
    ("socket wall 3 -> 0 mm", SCAD, "socket_wall = 3;", "socket_wall = 0;"),
    ("socket open at top (cavity flush with top)", SCAD, "socket_z0 = base_t + upright_h - socket_wall - socket_w;", "socket_z0 = base_t + upright_h - socket_w;"),
    # Known blind spot: edits SCAD construction code, which the Python mirror does not read.
    # Only a real OpenSCAD render test (audit action A-13) can catch it.
    ("socket block too short (cavity open at top)", SCAD, "cube([block_w, socket_depth, block_w]);", "cube([block_w, socket_depth, socket_w]);", True),
    ("hole pitch 50 -> 40 mm", SCAD, "hole_spacing = 50;", "hole_spacing = 40;"),
    ("foot width 80 -> 90 mm (SCAD only)", SCAD, "base_w = 80;", "base_w = 90;"),
    ("gusset run 32 -> 60 mm (blocks hole)", SCAD, "gusset_run = 32;", "gusset_run = 60;"),
    ("gusset thickness 8 -> 20 mm (reaches hole)", SCAD, "gusset_t = 8;", "gusset_t = 20;"),
]


def main():
    caught = 0
    rows = []
    blind = []
    detectable = 0
    for label, rel, old, new, *flag in [(*m, ) if len(m) == 5 else (*m, False) for m in MUTATIONS]:
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp) / "pkg"
            shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            target = work / rel
            text = target.read_text()
            if old not in text:
                rows.append(("SKIPPED ", label + "  (pattern not found: update mutation_check.py)"))
                continue
            target.write_text(text.replace(old, new, 1))
            r = subprocess.run([sys.executable, "-B", "-m", "unittest"], cwd=work / "03_Python",
                               capture_output=True, text=True)
            killed = r.returncode != 0
            if flag[0]:
                blind.append(label)
                rows.append(("BLIND   " if not killed else "CAUGHT  ", label + "  (known blind spot: needs real OpenSCAD render)"))
                continue
            detectable += 1
            caught += killed
            rows.append(("CAUGHT  " if killed else "SURVIVED", label))
    for status, label in rows:
        print(f"{status}  {label}")
    print(f"\nMutation score: {caught} / {detectable} detectable mutations caught"
          f" ({len(blind)} known blind spot(s) listed above)")
    return 0 if caught == detectable else 1


if __name__ == "__main__":
    sys.exit(main())
