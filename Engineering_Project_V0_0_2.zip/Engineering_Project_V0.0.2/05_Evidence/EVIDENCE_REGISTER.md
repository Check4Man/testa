# Evidence register
| Claim | Evidence required | Current status |
|---|---|---|
| Beam section is 20×20×2 mm | Exact supplier drawing/datasheet + incoming caliper measurements | OPEN |
| Beam is 6061-T6 | Supplier certificate or product datasheet | OPEN |
| Beam E and yield strength | Alloy/temper-specific authoritative datasheet | OPEN; script uses provisional 69 GPa / 240 MPa |
| Printed PETG strength and modulus | Filament TDS plus printed coupon tests in relevant orientations | OPEN; script placeholders 1.8 GPa / 30 MPa |
| Bracket press fit | Actual tube measurement + printed fit coupons and retention test | OPEN |
| Fastener dimensions/strength | Selected fastener datasheet and installation specification | OPEN |
| 10 N capacity | Analytical check + converged 3D FEA + physical proof test | OPEN |

## Evidence policy
Do not treat generic internet values as product-specific evidence. Record manufacturer, exact product code, datasheet revision/date, URL, access date, and relevant page/table. Store downloaded datasheets in this folder in the next release.
